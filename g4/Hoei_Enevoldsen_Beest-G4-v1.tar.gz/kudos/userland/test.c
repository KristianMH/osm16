#include "lib.h"

int main() {
  printf("hej\n");
  return 0;
}
