#ifndef KUDOS_PROC_MEMLIMIT
#define KUDOS_PROC_MEMLIMIT

#include "lib/types.h"
#include "lib/libc.h"
#include "vm/memory.h"


void *memlimit(void* new_end);




#endif
