/*
 * Writes the lengths of a buffer to a file.
 */


#ifndef KUDOS_PROC_WRITE_H
#define KUDOS_PROC_WRITE_H

int write(int filehandle, const void *buffer, int length);

#endif
