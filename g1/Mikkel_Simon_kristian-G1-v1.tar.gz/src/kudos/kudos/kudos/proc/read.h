/*
 * Reads the contents from the file.
 */


#ifndef KUDOS_PROC_READ_H
#define KUDOS_PROC_READ_H

int read(int filehandle, void *buffer, int length);

#endif
