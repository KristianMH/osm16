#include "lib.h"

int main(void) {
  syscall_read(d);
  syscall_write();
  syscall_halt();
  return 0;
}
