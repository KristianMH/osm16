#include "lib.h"

int main(void) {
  syscall_hello();
  syscall_halt();
  return 0;
}
